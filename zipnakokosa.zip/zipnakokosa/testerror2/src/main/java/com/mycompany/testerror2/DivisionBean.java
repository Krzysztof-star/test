package com.mycompany.testerror2;

import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Named;
import jakarta.faces.context.FacesContext;
import java.io.IOException;

@Named
@RequestScoped
public class DivisionBean {
    private int numerator;
    private int denominator;
    private String result;

    public int getNumerator() { return numerator; }
    public void setNumerator(int numerator) { this.numerator = numerator; }

    public int getDenominator() { return denominator; }
    public void setDenominator(int denominator) { this.denominator = denominator; }

    public String getResult() { return result; }
    public void setResult(String result) { this.result = result; }

    public void performDivision() {
        if (denominator == 0) {
            try {
                FacesContext.getCurrentInstance().getExternalContext().redirect("error.xhtml");
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            result = String.valueOf((double) numerator / denominator);
        }
    }
}
