package com.mycompany.hellofnamessname;

import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import java.io.Serializable;

@Named
@SessionScoped
public class UserBean implements Serializable {

    private String firstName;
    private String secondName;
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getSecondName() {
        return secondName;
    }

    public void setSecondName(String secondName) {
        this.secondName = secondName;
    }

    
    
//    public String submit() {
//        if (firstName == null || firstName.isEmpty() || secondName == null
//                || secondName.isEmpty()) {
//            return "error"; // Redirect to error page if data is missing
//        }
//        return "greeting?faces-redirect=true"; // Redirect to greeting page
//    }
    
    
    public String submit() {
    if (firstName == null || firstName.isEmpty() || secondName == null || secondName.isEmpty()) {
        return "error"; // Redirect to error page if data is missing
    }
    return "greeting?faces-redirect=true&fname=" + firstName + "&sname=" + secondName;
}

    

    public boolean isDataProvided() {
        return firstName != null && !firstName.isEmpty() && secondName != null
                && !secondName.isEmpty();
    }

    public String getGreetingMessage() {
        return "Hello " + firstName + " " + secondName;
    }
}

