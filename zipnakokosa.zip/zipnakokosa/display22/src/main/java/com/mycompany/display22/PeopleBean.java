package com.mycompany.display22;

import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import java.util.ArrayList;

import java.util.List;
@Named
@ApplicationScoped
public class PeopleBean {

    private List<Person> people;
    private String name;
    private String address;
    private String phoneNumber;

    @PostConstruct
    public void init() {
        people = new ArrayList<>();
    }

    public List<Person> getPeople() {
        return people;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void addPerson() {
        people.add(new Person(name, address, phoneNumber));
// Clear input fields after adding
        name = "";
        address = "";
        phoneNumber = "";
    }

    public static class Person {

        private String name;
        private String address;
        private String phoneNumber;

        public Person(String name, String address, String phoneNumber) {
            this.name = name;
            this.address = address;
            this.phoneNumber = phoneNumber;
        }

        public String getName() {
            return name;
        }

        public String getAddress() {
            return address;
        }

        public String getPhoneNumber() {
            return phoneNumber;
        }
    }
}
