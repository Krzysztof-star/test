package com.mycompany.przystosc;

import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import java.io.Serializable;

@Named
@SessionScoped
public class NumberBean implements Serializable {

    private Integer userNumber;

    public Integer getUserNumber() {
        return userNumber;
    }
    public void setUserNumber(Integer userNumber) {
        this.userNumber = userNumber;
    }

    public String submit() {
        if (userNumber == null) {
            return "error"; // Redirect to error page if input is invalid
        }
        return (userNumber % 2 == 0) ? "yolo?faces-redirect=true" : 

    "swag?facesredirect=true";
}
public boolean isNumberProvided() {
        return userNumber != null;
    }
}
