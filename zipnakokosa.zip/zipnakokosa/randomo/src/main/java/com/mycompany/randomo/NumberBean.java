
package com.mycompany.randomo;

import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import java.io.Serializable;
import java.util.Random;

@Named
@SessionScoped
public class NumberBean implements Serializable {

    private Integer userNumber;

    public Integer getUserNumber() {
        return userNumber;
    }

    public void setUserNumber(Integer userNumber) {
        this.userNumber = userNumber;
    }
    public String submit() {
        if (userNumber == null || userNumber <= 0) {
            return "error"; // Redirect to error page if input is invalid
        }
        return "random?faces-redirect=true"; // Redirect to the random page
    }

    public boolean isNumberProvided() {
        return userNumber != null && userNumber > 0;
    }

    public int getRandomNumber() {
        if (!isNumberProvided()) {
            throw new IllegalStateException(
            "User number must be provided before generating a random number.");
}
Random random = new Random();
        return userNumber + 1 + random.nextInt(100); // Generate a random number greater than userNumber
    }
}
