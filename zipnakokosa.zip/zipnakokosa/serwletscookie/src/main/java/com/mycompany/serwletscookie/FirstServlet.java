package com.mycompany.serwletscookie;


import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.Instant;

@WebServlet("/first")
public class FirstServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
// Create a cookie with the current timestamp
        String cookieName = "visitTime";
        String cookieValue = Instant.now().toString();
        Cookie cookie = new Cookie(cookieName, cookieValue);
        cookie.setMaxAge(30); // Expires in 30 seconds
        cookie.setPath("/"); // Make the cookie accessible across the entire app
// Add the cookie to the response
        response.addCookie(cookie);
// Send a simple message to the user
        response.setContentType("text/html");
        response.getWriter().println("<h1>Cookie has been set!</h1>");
        response.getWriter().println("<p>Visit <a href='second'>/second</a> to check the remaining time.< / p >");
    }
}

